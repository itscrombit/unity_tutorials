using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityStandardAssets.Characters.FirstPerson;

public class PauseGame : MonoBehaviour
{
    public GameObject menu;
    private GameObject player;
    public GameObject hud;
    private bool ispaused;


    void Start()
    {
        player = GameObject.Find("FPSController");//to get player in script make sure name is Exactly to which first person script is attached or you can assign it publicly above.
        menu.SetActive(false);
        ispaused = false;
    }
    public void Resume()
    {
        Debug.Log("pressed"); //Nevermind this Just Subscribe for Amazing Tutorials and Content.
        Time.timeScale = 1; // to set time any current animation (Basically Means to Stop Everything Like Magic)
        menu.SetActive(false); // to disable pause menu or to make it invisible when not in use
        ispaused = false; // bool to check if pause menu is currently open or not
        hud.SetActive(true); // to change hud or ui visibility
        Cursor.visible = false; //To chnge cursor visibility
        Cursor.lockState = CursorLockMode.Locked; //To Change Cursor Movement Locked = Not Moving, None = Free Cursor
        gameObject.GetComponent<AudioSource>().Play(); //To Get AudioSource From the GameObject on which this Script is Attached
        player.GetComponent<FirstPersonController>().enabled = true; //To Block Playe Movement
    }

    public void ReturnToMenu()
    {
        gameObject.GetComponent<AudioSource>().Play();
        SceneManager.LoadScene("Main Menu"); //to change scene to main menu
    }

    public void Exit()
    {
        gameObject.GetComponent<AudioSource>().Play();
        Application.Quit(); // game application will be stopped only will take place in actual gameplay not in editor
    }

    public void Update()
    {
        if (!ispaused && Input.GetKeyDown(KeyCode.Escape)) //You can change the pause menu opening key to either tab or anything assigned through input manager (Currently Escape Button)
        {
            Time.timeScale = 0;
            menu.SetActive(true);
            ispaused = true;
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
            player.GetComponent<FirstPersonController>().enabled = false;
            hud.SetActive(false);
        }

        else if (ispaused && Input.GetKeyDown(KeyCode.Escape))
        {
            Time.timeScale = 1;
            menu.SetActive(false);
            ispaused = false;
            Cursor.visible = false;
            hud.SetActive(true);
            Cursor.lockState = CursorLockMode.Locked;
            player.GetComponent<FirstPersonController>().enabled = true;
        }

    }
    
}
